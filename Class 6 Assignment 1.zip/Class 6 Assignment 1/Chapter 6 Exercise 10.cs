using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_6_Solution_10
{
    class Program
    {
        static void Main(string[] args)
		{
		    Console.Write("Enter N: (N < 20) ");
		    int n = Int32.Parse(Console.ReadLine());
		        
		    for (int i = 1; i <= n; i++)
		    {
		        for (int j = i; j <= i; j++)
		        {
		            Console.Write("{0} ", j);
		        }
		        Console.WriteLine();
		    }        
		}
    }
}